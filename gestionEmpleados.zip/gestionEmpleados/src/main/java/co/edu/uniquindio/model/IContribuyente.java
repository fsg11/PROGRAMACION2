package co.edu.uniquindio.model;

public interface IContribuyente {
    void contribuir(Proyecto proyecto);

}
